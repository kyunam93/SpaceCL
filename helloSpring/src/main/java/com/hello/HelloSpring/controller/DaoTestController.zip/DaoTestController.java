package com.hello.helloSpring.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hello.helloSpring.common.bean.MemberBean;
import com.hello.helloSpring.common.daos.MemberDao;

@Controller
public class DaoTestController {

	@Autowired
	private MemberDao memberDao;

	@RequestMapping(value = "/selectMember", method = { RequestMethod.GET })
	@ResponseBody
	public Map<String, Object> selectMember(String id) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		MemberBean bean = new MemberBean();
		
		
		
		return map;
	}// method
}// class
